import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amain',
  templateUrl: './amain.component.html',
  styleUrls: ['./amain.component.css']
})
export class AmainComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
