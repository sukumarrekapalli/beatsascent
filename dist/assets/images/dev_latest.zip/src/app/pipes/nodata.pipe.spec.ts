import { NodataPipe } from './nodata.pipe';

describe('NodataPipe', () => {
  it('create an instance', () => {
    const pipe = new NodataPipe();
    expect(pipe).toBeTruthy();
  });
});
