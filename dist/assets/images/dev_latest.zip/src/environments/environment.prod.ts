export const environment = {
  production: true,
  // https: true,
  https: false,
 	// apiUrl: "https://pulsedb.culturelytics.in"  
  // apiUrl: "http://115.124.109.123:1800"
  apiUrl: "http://pulsedb.utopiansunrise.in"
};
